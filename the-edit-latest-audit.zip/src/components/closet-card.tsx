import Link from "next/link";
import { AtelierPlaceholder } from "@/components/atelier-placeholder";
import type { WardrobeItem } from "@/types/wardrobe";

type ClosetCardProps = {
  item: WardrobeItem;
  onSelect?: (item: WardrobeItem) => void;
};

function getClosetScore(item: WardrobeItem) {
  const scores = [
    item.loveScore,
    item.versatilityScore,
    item.fitConfidenceScore,
    item.capsuleValueScore,
  ].filter((score): score is number => typeof score === "number");

  if (!scores.length) return null;

  const average =
    scores.reduce((total, score) => total + score, 0) / scores.length;

  return Number(average.toFixed(1));
}

function formatCategory(category: string) {
  return category.replace("-", " ");
}

function formatVibes(vibes: string[]) {
  if (!vibes.length) return "Needs styling data";
  return vibes.slice(0, 3).join(" · ");
}

function ScorePill({ label, score }: { label: string; score?: number }) {
  if (typeof score !== "number") return null;

  return (
    <div className="rounded-full bg-white/58 px-3 py-2 text-center shadow-[inset_0_0_0_1px_rgba(48,35,31,0.04)]">
      <p className="text-[0.48rem] font-bold uppercase tracking-[0.16em] text-[var(--caramel)]">
        {label}
      </p>
      <p className="font-display text-lg leading-none text-[var(--espresso)]">
        {score}
      </p>
    </div>
  );
}

function ClosetCardContent({ item }: { item: WardrobeItem }) {
  const closetScore = getClosetScore(item);
  const hasScores = [
    item.loveScore,
    item.versatilityScore,
    item.fitConfidenceScore,
    item.capsuleValueScore,
  ].some((score) => typeof score === "number");

  return (
    <div className="flex h-full flex-col">
      <div className="relative p-3">
        <div className="relative overflow-hidden rounded-[1.55rem] bg-[linear-gradient(145deg,var(--paper-3),rgba(255,253,252,0.72))]">
          {item.imageUrl ? (
            <div
              className="h-[21rem] bg-contain bg-center bg-no-repeat transition duration-500 group-hover:scale-[1.025]"
              style={{ backgroundImage: `url(${item.imageUrl})` }}
              aria-label={item.name}
            />
          ) : (
            <AtelierPlaceholder
              name={item.name}
              colorName={item.colorName}
              colorFamily={item.colorFamily}
              category={formatCategory(item.category)}
              className="h-[21rem]"
            />
          )}

          <div className="absolute left-3 top-3 rounded-full bg-white/74 px-3 py-2 text-[0.52rem] font-bold uppercase tracking-[0.16em] text-[var(--espresso)] backdrop-blur-xl">
            {formatCategory(item.category)}
          </div>

          {closetScore !== null ? (
            <div className="absolute right-3 top-3 grid h-14 w-14 place-items-center rounded-full bg-[var(--burgundy)] text-white shadow-[0_12px_26px_rgba(122,46,53,0.22)]">
              <div className="text-center">
                <p className="font-display text-xl leading-none">{closetScore}</p>
                <p className="text-[0.42rem] font-bold uppercase tracking-[0.12em]">score</p>
              </div>
            </div>
          ) : null}

          {item.itemStatus && item.itemStatus !== "active" ? (
            <div className="absolute bottom-3 left-3 rounded-full bg-[var(--plum)] px-3 py-2 text-[0.5rem] font-bold uppercase tracking-[0.16em] text-white">
              {item.itemStatus}
            </div>
          ) : null}
        </div>
      </div>

      <div className="flex flex-1 flex-col px-5 pb-5 pt-3 text-left">
        <div className="mb-3 flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-[0.55rem] font-bold uppercase tracking-[0.20em] text-[var(--burgundy)]">
              {item.colorName} · {item.size ?? "One size"}
            </p>
            <h3 className="mt-2 font-display text-[2.2rem] leading-[0.95] text-[var(--espresso)]">
              {item.name}
            </h3>
          </div>
        </div>

        <p className="text-[0.62rem] font-bold uppercase tracking-[0.18em] text-[var(--caramel)]">
          {formatVibes(item.vibes)}
        </p>

        {hasScores ? (
          <div className="mt-4 grid grid-cols-4 gap-1.5">
            <ScorePill label="Love" score={item.loveScore} />
            <ScorePill label="Vers" score={item.versatilityScore} />
            <ScorePill label="Fit" score={item.fitConfidenceScore} />
            <ScorePill label="Caps" score={item.capsuleValueScore} />
          </div>
        ) : null}

        {(item.paidPrice || item.purchaseSource || item.purchaseDate) ? (
          <div className="mt-4 flex flex-wrap gap-2">
            {item.paidPrice ? <span className="edit-chip">${item.paidPrice}</span> : null}
            {item.purchaseSource ? <span className="edit-chip">{item.purchaseSource}</span> : null}
            {item.purchaseDate ? <span className="edit-chip">{item.purchaseDate}</span> : null}
          </div>
        ) : null}

        <div className="mt-auto pt-5">
          <div className="rounded-[1.25rem] bg-white/44 p-4">
            <p className="text-[0.52rem] font-bold uppercase tracking-[0.22em] text-[var(--burgundy)]">
              Stylist note
            </p>
            <p className="mt-2 line-clamp-3 text-[0.86rem] leading-6 text-[var(--ink-soft)]">
              {item.stylingNotes ?? item.notes ?? "Add styling notes so THE EDIT can learn how this piece works in real outfits."}
            </p>
          </div>

          {item.productUrl ? (
            <a
              href={item.productUrl}
              target="_blank"
              rel="noreferrer"
              onClick={(event) => event.stopPropagation()}
              className="mt-4 inline-flex text-[0.56rem] font-bold uppercase tracking-[0.18em] text-[var(--burgundy)] underline-offset-4 hover:underline"
            >
              Product link
            </a>
          ) : null}
        </div>
      </div>
    </div>
  );
}

const cardClassName =
  "group block h-full w-full overflow-hidden rounded-[1.85rem] bg-[rgba(255,253,252,0.70)] text-left no-underline shadow-[inset_0_1px_0_rgba(255,255,255,0.88),0_18px_48px_rgba(74,52,42,0.09)] transition duration-300 hover:-translate-y-1 hover:shadow-[inset_0_1px_0_rgba(255,255,255,0.92),0_26px_64px_rgba(74,52,42,0.14)]";

export function ClosetCard({ item, onSelect }: ClosetCardProps) {
  if (onSelect) {
    return (
      <button
        type="button"
        onClick={() => onSelect(item)}
        className={cardClassName}
      >
        <ClosetCardContent item={item} />
      </button>
    );
  }

  return (
    <Link href={`/closet/${item.id}`} className={cardClassName}>
      <ClosetCardContent item={item} />
    </Link>
  );
}
